#ifndef _MYSTRING_H_
#define _MYSTRING_H_

// 字符串拷贝
char *mystrcpy(char *des, char *src);
// 比较两个字符串的大小
int mystrcmp(char *str1, char *str2);
#endif